

def get_input_from_user():
    pass


def get_input_from_file():
    pass


def get_input_from_csv_file():
    pass
