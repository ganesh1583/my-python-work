from csv_module.input_to_csv import input_to_new_csv_file, input_to_existing_csv_file
from csv_module.output_from_csv import get_data_from_csv_file
from normal_file.input_to_file import add_data_to_new_normal_file, add_data_to_existing_normal_file
from normal_file.output_from_file import get_data_from_file

#add_data_to_new_normal_file()
#add_data_to_existing_normal_file()
#get_data_from_file()

#input_to_new_csv_file()
#input_to_existing_csv_file()
#get_data_from_csv_file()